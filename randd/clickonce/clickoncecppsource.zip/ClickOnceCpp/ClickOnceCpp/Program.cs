using System;
using System.Diagnostics;
using System.Windows.Forms;

namespace Kennedy.ClickOnceCpp
{
	class Program
	{
		static void Main(string[] args)
		{
			try
			{
				Process.Start( "TheRealApp.exe" );
			}
			catch ( Exception x )
			{
				string msg = "Error launch application:\n\n" + x;
				string cap = "Error Launching Application";
				MessageBox.Show( msg, cap, MessageBoxButtons.OK, MessageBoxIcon.Error );
			}
		}
	}
}
