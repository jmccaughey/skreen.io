// TheRealAppDoc.cpp : implementation of the CTheRealAppDoc class
//

#include "stdafx.h"
#include "TheRealApp.h"

#include "TheRealAppDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CTheRealAppDoc

IMPLEMENT_DYNCREATE(CTheRealAppDoc, CDocument)

BEGIN_MESSAGE_MAP(CTheRealAppDoc, CDocument)
END_MESSAGE_MAP()


// CTheRealAppDoc construction/destruction

CTheRealAppDoc::CTheRealAppDoc()
{
	// TODO: add one-time construction code here

}

CTheRealAppDoc::~CTheRealAppDoc()
{
}

BOOL CTheRealAppDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}




// CTheRealAppDoc serialization

void CTheRealAppDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}


// CTheRealAppDoc diagnostics

#ifdef _DEBUG
void CTheRealAppDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CTheRealAppDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG


// CTheRealAppDoc commands
