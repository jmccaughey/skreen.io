// TheRealAppView.cpp : implementation of the CTheRealAppView class
//

#include "stdafx.h"
#include "TheRealApp.h"

#include "TheRealAppDoc.h"
#include "TheRealAppView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CTheRealAppView

IMPLEMENT_DYNCREATE(CTheRealAppView, CView)

BEGIN_MESSAGE_MAP(CTheRealAppView, CView)
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, &CView::OnFilePrintPreview)
END_MESSAGE_MAP()

// CTheRealAppView construction/destruction

CTheRealAppView::CTheRealAppView()
{
	// TODO: add construction code here

}

CTheRealAppView::~CTheRealAppView()
{
}

BOOL CTheRealAppView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

// CTheRealAppView drawing

void CTheRealAppView::OnDraw(CDC* /*pDC*/)
{
	CTheRealAppDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;

	// TODO: add draw code for native data here
}


// CTheRealAppView printing

BOOL CTheRealAppView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CTheRealAppView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CTheRealAppView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}


// CTheRealAppView diagnostics

#ifdef _DEBUG
void CTheRealAppView::AssertValid() const
{
	CView::AssertValid();
}

void CTheRealAppView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CTheRealAppDoc* CTheRealAppView::GetDocument() const // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CTheRealAppDoc)));
	return (CTheRealAppDoc*)m_pDocument;
}
#endif //_DEBUG


// CTheRealAppView message handlers
